printf "\n\n##### Beginning 01600-install-and-configure-sysstat.sh\n\n" >> /root/report/build-report.txt

printf "\n## INSTALL AND CONFIGURE SYSTAT\n\n"

apt-get -y install sysstat
