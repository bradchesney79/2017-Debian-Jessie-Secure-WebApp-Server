printf "\n\n##### Beginning 02300-install-redis.sh\n\n" >> /root/report/build-report.txt

printf "\n## INSTALL REDIS CACHE\n\n"

apt-get -y install redis-server


