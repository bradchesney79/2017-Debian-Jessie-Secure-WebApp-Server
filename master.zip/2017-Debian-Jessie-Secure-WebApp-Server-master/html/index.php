<?php

include $getenv('webroot')